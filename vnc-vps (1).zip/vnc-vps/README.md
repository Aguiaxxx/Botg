# VNC XFCE Server — VPS Linux

Servidor de área de trabalho remota com **XFCE + noVNC + Google Chrome + Cloudflare Tunnel**, adaptado do Google Colab para execução contínua em VPS Linux (Ubuntu/Debian).

---

## Requisitos

| Item | Versão mínima |
|------|--------------|
| Sistema operacional | Ubuntu 20.04+ / Debian 11+ (amd64) |
| Python | 3.10+ |
| Acesso | root (`sudo`) |
| Conexão | Internet (para baixar dependências na 1ª execução) |
| RAM | 1 GB mínimo (2 GB recomendado) |
| Disco | 2 GB livres |

---

## Instalação

### 1. Clone ou copie os arquivos para a VPS

```bash
# Opção A: via git
git clone <seu-repositorio> vnc-vps
cd vnc-vps

# Opção B: copie os arquivos manualmente para a VPS via scp/sftp
```

### 2. Execute o setup inicial (apenas uma vez)

```bash
chmod +x setup.sh
sudo ./setup.sh
```

O setup:
- Verifica a versão do Python
- Cria o arquivo `.env` com uma **senha VNC aleatória e segura**
- Ajusta permissões dos arquivos

### 3. (Opcional) Ajuste as configurações

```bash
nano .env
```

Exemplo de `.env`:
```env
VNC_PASSWD=minha_senha_aqui
VNC_SCREEN_RES=1920x1080x24
NOVNC_PORT=6080
CHROME_START_URL=https://google.com
```

---

## Uso

### Iniciar o servidor (completo)

```bash
sudo python3 main.py
```

Na primeira execução, instala automaticamente:
- `xfce4` + utilitários
- `xvfb`, `x11vnc`
- `noVNC` + websockify
- `Google Chrome`
- `Cloudflared`

Ao final, exibe um link público como:
```
https://abc123.trycloudflare.com/vnc.html?autoconnect=true&resize=remote&password=...
```

Abra esse link em qualquer navegador para acessar a área de trabalho.

---

### Opções de linha de comando

```bash
# Iniciar sem criar túnel Cloudflare (acesso apenas pela porta local)
sudo python3 main.py --no-tunnel

# Iniciar sem abrir o Chrome automaticamente
sudo python3 main.py --no-chrome

# Pular instalação de dependências (nas execuções seguintes)
sudo python3 main.py --no-install

# Parar todos os serviços
sudo python3 main.py --stop

# Combinando opções
sudo python3 main.py --no-tunnel --no-chrome --no-install
```

---

## Acesso local (sem Cloudflare)

Se preferir não usar o túnel Cloudflare, abra a porta no firewall e acesse diretamente:

```bash
# Abre a porta do noVNC
ufw allow 6080/tcp

# Acesse via navegador
http://IP_DA_VPS:6080/vnc.html?autoconnect=true&password=SUA_SENHA
```

---

## Estrutura do projeto

```
vnc-vps/
├── main.py          # Ponto de entrada — orquestrador principal
├── config.py        # Configurações (lidas de .env / variáveis de ambiente)
├── installer.py     # Instalação de dependências do sistema
├── services.py      # Inicialização dos serviços (Xvfb, XFCE, VNC, noVNC, Chrome)
├── tunnel.py        # Gerenciamento do túnel Cloudflare
├── setup.sh         # Script de configuração inicial (execute uma vez)
├── .env             # Suas configurações (criado pelo setup.sh, não versionar)
├── .env.example     # Modelo de configuração
├── requirements.txt # Dependências Python (apenas stdlib — sem pip install)
└── README.md        # Este arquivo
```

---

## Variáveis de ambiente

| Variável | Padrão | Descrição |
|----------|--------|-----------|
| `VNC_PASSWD` | `vncpass` | **Senha VNC — altere antes de usar em produção** |
| `VNC_PERSIST_HOME` | `~/vnc_persist` | Diretório de persistência (Downloads, perfil Chrome) |
| `VNC_SCREEN_RES` | `1366x768x24` | Resolução da tela virtual |
| `VNC_DISPLAY_NUM` | `99` | Número do display X virtual |
| `VNC_PORT` | `5900` | Porta do servidor VNC |
| `NOVNC_PORT` | `6080` | Porta do noVNC (acesso pelo navegador) |
| `CHROME_START_URL` | `https://google.com` | URL inicial do Chrome |

---

## Diferenças em relação à versão do Google Colab

| Recurso Colab | Substituição na VPS |
|--------------|---------------------|
| `google.colab` import | Removido — não necessário |
| `drive.mount()` | Substituído por diretório local (`VNC_PERSIST_HOME`) |
| Comandos mágicos `!` | `subprocess.run()` nativo |
| Detecção `IS_COLAB` | Removida — ambiente VPS fixo |
| Persistência no Drive | Diretório local persistente configurável via `.env` |
| Senha hardcoded no código | Variável de ambiente `VNC_PASSWD` no `.env` |
| Script monolítico | Organizado em módulos separados |

---

## Segurança

- A senha VNC é definida via variável de ambiente — **nunca hardcode no código**
- O arquivo `.env` tem permissão `600` (apenas root lê)
- O túnel Cloudflare é temporário (muda a cada reinício) — ideal para uso pessoal
- Para produção, considere usar um túnel nomeado com token: `cloudflared tunnel login`
- Nunca exponha a porta VNC (5900) diretamente na internet sem autenticação adicional

---

## Solução de problemas

**Xvfb não inicia:**
```bash
# Verifique se há locks anteriores
ls /tmp/.X*-lock
rm -f /tmp/.X99-lock
```

**noVNC não conecta:**
```bash
# Verifique se os serviços estão rodando
pgrep -a Xvfb
pgrep -a x11vnc
pgrep -a websockify
```

**Chrome não abre:**
```bash
# Teste manualmente
DISPLAY=:99 google-chrome --no-sandbox --disable-gpu https://google.com
```

**URL Cloudflare não aparece:**
```bash
# Veja o log do cloudflared
cat /tmp/cloudflared.log
```
