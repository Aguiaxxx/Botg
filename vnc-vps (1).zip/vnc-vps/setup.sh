#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════
#  setup.sh — Configuração rápida do VNC Server para VPS Linux
#  Execute UMA VEZ antes de rodar main.py:
#    chmod +x setup.sh && sudo ./setup.sh
# ════════════════════════════════════════════════════════════

set -euo pipefail

# ─── Verifica root ──────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
    echo ""
    echo "❌ Execute como root:"
    echo "   sudo ./setup.sh"
    echo ""
    exit 1
fi

# ─── Banner ─────────────────────────────────────────────────
echo "════════════════════════════════════════════════════════"
echo "  VNC XFCE — Setup Inicial para VPS Linux"
echo "════════════════════════════════════════════════════════"

# ─── Python 3.10+ ───────────────────────────────────────────
echo ""
echo "⏳ Verificando Python 3..."

PY_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
PY_MAJOR=$(echo "$PY_VERSION" | cut -d. -f1)
PY_MINOR=$(echo "$PY_VERSION" | cut -d. -f2)

if [[ "$PY_MAJOR" -lt 3 ]] || [[ "$PY_MAJOR" -eq 3 && "$PY_MINOR" -lt 10 ]]; then
    echo "⚠  Python $PY_VERSION detectado. Recomendado: 3.10+"
    echo "   Tentando instalar python3.10..."
    apt-get update -qq
    apt-get install -y -qq python3.10 python3.10-distutils || {
        echo "   Continuando com Python $PY_VERSION (pode haver incompatibilidade de tipos)"
    }
else
    echo "✅ Python $PY_VERSION — OK"
fi

# ─── Cria .env se não existir ────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! -f "$SCRIPT_DIR/.env" ]]; then
    echo ""
    echo "📝 Criando arquivo .env a partir do exemplo..."
    cp "$SCRIPT_DIR/.env.example" "$SCRIPT_DIR/.env"

    # Gera senha aleatória segura
    RANDOM_PASS=$(tr -dc 'A-Za-z0-9!@#$%' < /dev/urandom | head -c 16)
    sed -i "s/minha_senha_segura_aqui/$RANDOM_PASS/" "$SCRIPT_DIR/.env"

    echo ""
    echo "✅ .env criado com senha aleatória."
    echo ""
    echo "   ┌─────────────────────────────────────┐"
    echo "   │  VNC_PASSWD=$RANDOM_PASS"
    echo "   └─────────────────────────────────────┘"
    echo ""
    echo "   Guarde essa senha! Você pode alterá-la editando .env"
else
    echo ""
    echo "✅ .env já existe — mantido sem alterações"
fi

# ─── Permissões ──────────────────────────────────────────────
chmod 600 "$SCRIPT_DIR/.env"
chmod +x  "$SCRIPT_DIR/main.py" 2>/dev/null || true

# ─── Concluído ───────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════════════════════"
echo "  ✅ Setup concluído!"
echo ""
echo "  Para iniciar o servidor VNC:"
echo "    sudo python3 main.py"
echo ""
echo "  Para iniciar sem criar túnel Cloudflare:"
echo "    sudo python3 main.py --no-tunnel"
echo ""
echo "  Para parar todos os serviços:"
echo "    sudo python3 main.py --stop"
echo "════════════════════════════════════════════════════════"
