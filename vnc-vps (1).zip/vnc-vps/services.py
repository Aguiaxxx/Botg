"""
services.py — Inicialização e gerenciamento dos serviços VNC
Usa listas de argumentos em vez de shell=True para evitar injeção de comandos.
"""

import os
import subprocess
import sys
import time

from config import (
    DISPLAY,
    DISPLAY_NUM,
    NOVNC_DIR,
    NOVNC_PORT,
    PERSIST_HOME,
    SCREEN_RES,
    VNC_PASSWD,
    VNC_PORT,
    CHROME_START_URL,
)
from progress import Progress


# ─── Helpers ──────────────────────────────────────────────────────────────────

def is_running(name: str) -> bool:
    return (
        subprocess.run(
            ["pgrep", "-f", name],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0
    )


def kill_proc(name: str) -> None:
    subprocess.run(
        ["pkill", "-f", name],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(0.5)


def _env() -> dict:
    """Retorna o ambiente com DISPLAY e HOME corretos."""
    return {**os.environ, "DISPLAY": DISPLAY, "HOME": PERSIST_HOME}


# ─── Limpeza ─────────────────────────────────────────────────────────────────

def stop_all(progress: Progress | None = None) -> None:
    """Para todos os serviços e limpa arquivos de lock."""
    if progress:
        progress.step("Limpando serviços anteriores")
    print("\n🧹 Parando serviços anteriores...")
    for proc in [
        "Xvfb", "x11vnc", "xfce4-session", "xfwm4",
        "websockify", "cloudflared", "chrome", "chromium",
    ]:
        kill_proc(proc)

    lock = f"/tmp/.X{DISPLAY_NUM}-lock"
    if os.path.exists(lock):
        os.remove(lock)
        print(f"   Removido lock: {lock}")


# ─── Xvfb ────────────────────────────────────────────────────────────────────

def start_xvfb(progress: Progress | None = None) -> bool:
    if progress:
        progress.step("Iniciando Xvfb (display virtual)")
    print("\n🚀 Iniciando Xvfb...")
    w, h, d = SCREEN_RES.split("x")
    subprocess.Popen(
        [
            "Xvfb", DISPLAY,
            "-screen", "0", SCREEN_RES,
            "-ac", "+extension", "GLX", "+render", "-noreset",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(3)
    ok = is_running("Xvfb")
    print(f"{'✅' if ok else '❌'} Xvfb")
    if not ok:
        print("❌ Xvfb não iniciou — encerrando.", file=sys.stderr)
        sys.exit(1)
    return ok


# ─── XFCE ────────────────────────────────────────────────────────────────────

def start_xfce(progress: Progress | None = None) -> bool:
    if progress:
        progress.step("Iniciando XFCE (área de trabalho)")
    print("🚀 Iniciando XFCE...")
    subprocess.Popen(
        ["startxfce4"],
        env=_env(),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(6)
    ok = is_running("xfce4") or is_running("xfwm4")
    print(f"{'✅' if ok else '⚠ (ainda carregando — pode ser normal)'} XFCE")
    return ok


# ─── x11vnc ───────────────────────────────────────────────────────────────────

def start_x11vnc(progress: Progress | None = None) -> bool:
    if progress:
        progress.step("Iniciando x11vnc (servidor VNC)")
    print("🚀 Iniciando x11vnc...")
    subprocess.Popen(
        [
            "x11vnc",
            "-display", DISPLAY,
            "-rfbport", str(VNC_PORT),
            "-passwd", VNC_PASSWD,
            "-forever",
            "-shared",
            "-noxdamage",
            "-repeat",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(2)
    ok = is_running("x11vnc")
    print(f"{'✅' if ok else '❌'} x11vnc (porta {VNC_PORT})")
    if not ok:
        print("❌ x11vnc não iniciou — encerrando.", file=sys.stderr)
        sys.exit(1)
    return ok


# ─── noVNC ───────────────────────────────────────────────────────────────────

def start_novnc(progress: Progress | None = None) -> bool:
    if progress:
        progress.step("Iniciando noVNC (acesso via navegador)")
    print("🚀 Iniciando noVNC...")
    subprocess.Popen(
        [
            f"{NOVNC_DIR}/utils/websockify/run",
            "--web", NOVNC_DIR,
            str(NOVNC_PORT),
            f"localhost:{VNC_PORT}",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(2)
    ok = is_running("websockify")
    print(f"{'✅' if ok else '❌'} noVNC (porta {NOVNC_PORT})")
    if not ok:
        print("❌ noVNC não iniciou — encerrando.", file=sys.stderr)
        sys.exit(1)
    return ok


# ─── Chrome ───────────────────────────────────────────────────────────────────

def start_chrome(progress: Progress | None = None) -> None:
    if progress:
        progress.step("Abrindo Google Chrome")
    print("🚀 Abrindo Google Chrome...")
    subprocess.Popen(
        [
            "google-chrome",
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-gpu",
            "--start-maximized",
            f"--user-data-dir={PERSIST_HOME}/chrome-profile",
            "--new-window",
            CHROME_START_URL,
        ],
        env=_env(),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(5)
    print("✅ Chrome aberto")


# ─── Persistência ─────────────────────────────────────────────────────────────

def setup_persistence(progress: Progress | None = None) -> None:
    if progress:
        progress.step("Configurando persistência")
    print("\n📦 Configurando persistência...")
    os.makedirs(f"{PERSIST_HOME}/Downloads", exist_ok=True)
    os.makedirs(f"{PERSIST_HOME}/chrome-profile", exist_ok=True)

    # Symlink ~/Downloads → PERSIST_HOME/Downloads (sem shell)
    downloads_link = os.path.expanduser("~/Downloads")
    target = os.path.join(PERSIST_HOME, "Downloads")
    if os.path.islink(downloads_link):
        os.remove(downloads_link)
    elif os.path.isdir(downloads_link):
        pass  # já existe como diretório real — não sobrescreve
    else:
        os.symlink(target, downloads_link)

    print(f"✅ Persistência em: {PERSIST_HOME}")


# ─── VNC password ─────────────────────────────────────────────────────────────

def configure_vnc_password(progress: Progress | None = None) -> None:
    if progress:
        progress.step("Configurando senha VNC")
    print("\n" + "═" * 60)
    print("  CONFIGURANDO VNC")
    print("═" * 60)
    vnc_dir = os.path.join(PERSIST_HOME, ".vnc")
    os.makedirs(vnc_dir, exist_ok=True)
    passwd_file = os.path.join(vnc_dir, "passwd")
    subprocess.run(
        ["x11vnc", "-storepasswd", VNC_PASSWD, passwd_file],
        capture_output=True,
    )
    os.chmod(passwd_file, 0o600)
    print("✅ Senha VNC configurada")


# ─── Orquestração ─────────────────────────────────────────────────────────────

def start_all(progress: Progress | None = None, open_chrome: bool = True) -> None:
    """
    Inicia todos os serviços na ordem correta.
    Aborta imediatamente se um serviço crítico (Xvfb, x11vnc, noVNC) falhar.
    """
    setup_persistence(progress)
    configure_vnc_password(progress)
    stop_all(progress)
    start_xvfb(progress)
    start_xfce(progress)
    start_x11vnc(progress)
    start_novnc(progress)
    if open_chrome:
        start_chrome(progress)
