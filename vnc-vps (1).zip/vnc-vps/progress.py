"""
progress.py — Rastreador de progresso da instalação (em %)
Mostra uma barra de progresso e a porcentagem concluída da instalação
inteira, somando as etapas de instalação de dependências e de
inicialização dos serviços.
"""

import sys


class Progress:
    """
    Rastreia o progresso de uma sequência de etapas nomeadas e imprime
    uma barra de progresso com a porcentagem concluída antes de cada uma.
    """

    BAR_LEN = 28

    def __init__(self, total_steps: int) -> None:
        self.total = max(total_steps, 1)
        self.current = 0

    def step(self, desc: str = "") -> None:
        """Avança uma etapa e imprime a barra de progresso atualizada."""
        self.current = min(self.current + 1, self.total)
        pct = int(self.current * 100 / self.total)
        filled = int(self.BAR_LEN * pct / 100)
        bar = "█" * filled + "░" * (self.BAR_LEN - filled)

        line = f"\n[{bar}] {pct:3d}%  ({self.current}/{self.total})"
        if desc:
            line += f"  {desc}..."
        print(line, flush=True)

    def done(self) -> None:
        """Força a barra para 100% e imprime a mensagem final."""
        self.current = self.total
        bar = "█" * self.BAR_LEN
        print(f"\n[{bar}] 100%  ({self.total}/{self.total})  Instalação concluída", flush=True)

    @staticmethod
    def noop_step(desc: str = "") -> None:
        """Usado quando não há um Progress ativo — mantém o print simples."""
        if desc:
            print(f"⏳ {desc}...", file=sys.stderr)
