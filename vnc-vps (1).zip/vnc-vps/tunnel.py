"""
tunnel.py — Gerenciamento do túnel Cloudflare
Não interpola VNC_PASSWD em comandos shell — usa lista de argumentos.
"""

import os
import re
import subprocess
import sys
import time

from config import CLOUDFLARED_PATH, CLOUDFLARED_LOG, NOVNC_PORT, VNC_PASSWD
from progress import Progress


def kill_cloudflared() -> None:
    subprocess.run(
        ["pkill", "-f", "cloudflared"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(1)


def start_tunnel(progress: Progress | None = None) -> str | None:
    """
    Inicia um túnel Cloudflare temporário (trycloudflare.com) e retorna
    a URL pública. Retorna None se não conseguir obter a URL em 120 s.

    Diferença do Colab: no Colab era comum usar ngrok via JS/!ngrok.
    Aqui usamos cloudflared diretamente, sem shell=True.
    """
    if progress:
        progress.step("Gerando túnel público (Cloudflare)")
    print("\n" + "═" * 60)
    print("  GERANDO LINK PÚBLICO (Cloudflare Tunnel)")
    print("═" * 60)

    kill_cloudflared()

    if os.path.exists(CLOUDFLARED_LOG):
        os.remove(CLOUDFLARED_LOG)

    # Abre log em arquivo (sem shell redirect — usamos stdout do Popen)
    log_fd = open(CLOUDFLARED_LOG, "w")
    subprocess.Popen(
        [
            CLOUDFLARED_PATH,
            "tunnel",
            "--url", f"http://localhost:{NOVNC_PORT}",
        ],
        stdout=log_fd,
        stderr=log_fd,
    )

    public_url: str | None = None

    print("⏳ Aguardando URL pública", end="", flush=True)
    for _ in range(60):
        time.sleep(2)
        print(".", end="", flush=True)

        try:
            with open(CLOUDFLARED_LOG, "r", errors="ignore") as f:
                logs = f.read()
        except OSError:
            continue

        match = re.search(
            r"https://[-a-zA-Z0-9]+\.trycloudflare\.com",
            logs,
        )
        if match:
            public_url = match.group(0)
            break

    print()  # nova linha
    return public_url


def print_result(public_url: str | None, persist_home: str) -> None:
    print("\n" + "═" * 60)

    if public_url:
        # A senha é incluída na URL para facilitar a conexão automática.
        # Atenção: não registre essa URL em logs de acesso público.
        url = (
            f"{public_url}/vnc.html"
            f"?autoconnect=true"
            f"&resize=remote"
            f"&password={VNC_PASSWD}"
        )
        print("🌍 ACESSO REMOTO VIA NAVEGADOR:")
        print()
        print(f"  {url}")
        print()
        print("  ⚠  Não compartilhe esse link — ele contém sua senha VNC.")
    else:
        print("❌ Não foi possível gerar URL pública via Cloudflare.")
        print()
        print("   Acesso LOCAL disponível em:")
        print(
            f"   http://localhost:{NOVNC_PORT}/vnc.html"
            f"?autoconnect=true&password={VNC_PASSWD}"
        )
        print()
        print("   Para acesso externo sem Cloudflare, abra a porta no firewall:")
        print(f"     ufw allow {NOVNC_PORT}/tcp")
        print()
        print("   E acesse via:")
        print(
            f"   http://IP_DA_VPS:{NOVNC_PORT}/vnc.html"
            f"?autoconnect=true&password={VNC_PASSWD}"
        )

    print("═" * 60)
    print(f"""
✅ SISTEMA ONLINE

HOME persistente : {persist_home}
Senha VNC        : (definida em .env / VNC_PASSWD)

SERVIÇOS ATIVOS:
  • Xvfb       (display virtual)
  • XFCE       (área de trabalho)
  • x11vnc     (servidor VNC, porta {5900})
  • noVNC      (acesso via browser, porta {NOVNC_PORT})
  • Chrome     (browser interno)
  • Cloudflare (túnel público)

Para parar todos os serviços:
  sudo python3 main.py --stop
""")
