"""
config.py — Configurações centrais do VNC Server
Todos os parâmetros são lidos de variáveis de ambiente com fallback seguro.
Validação de tipos e valores é feita aqui — falhas abortam na importação.
"""

import os
import re
import sys

# ─── Helpers de validação ─────────────────────────────────────────────────────

def _get_port(name: str, default: int) -> int:
    raw = os.environ.get(name, str(default))
    try:
        port = int(raw)
    except ValueError:
        print(f"[ERRO] {name}='{raw}' não é um número inteiro válido.", file=sys.stderr)
        sys.exit(1)
    if not (1024 <= port <= 65535):
        print(f"[ERRO] {name}={port} fora do intervalo permitido (1024-65535).", file=sys.stderr)
        sys.exit(1)
    return port


def _get_int(name: str, default: int) -> int:
    raw = os.environ.get(name, str(default))
    try:
        return int(raw)
    except ValueError:
        print(f"[ERRO] {name}='{raw}' não é um inteiro válido.", file=sys.stderr)
        sys.exit(1)


def _validate_password(passwd: str) -> str:
    """
    Rejeita senhas que contenham caracteres especiais de shell para evitar
    injeção de comandos (o script roda como root).
    Permitido: letras, números, e os símbolos: !@#$%^&*()-_+=
    """
    if not passwd:
        print("[ERRO] VNC_PASSWD não pode ser vazio.", file=sys.stderr)
        sys.exit(1)
    if len(passwd) < 6:
        print("[ERRO] VNC_PASSWD deve ter ao menos 6 caracteres.", file=sys.stderr)
        sys.exit(1)
    if not re.fullmatch(r"[A-Za-z0-9!@#$%^&*()\-_+=]{6,64}", passwd):
        print(
            "[ERRO] VNC_PASSWD contém caracteres não permitidos.\n"
            "       Use apenas: letras, números e !@#$%^&*()-_+=",
            file=sys.stderr,
        )
        sys.exit(1)
    return passwd


def _validate_resolution(res: str) -> str:
    if not re.fullmatch(r"\d+x\d+x\d+", res):
        print(
            f"[ERRO] VNC_SCREEN_RES='{res}' tem formato inválido. "
            "Use WxHxD, ex: 1366x768x24",
            file=sys.stderr,
        )
        sys.exit(1)
    return res


def _validate_url(url: str) -> str:
    if not re.match(r"https?://[^\s\"';|&<>]+$", url):
        print(
            f"[ERRO] CHROME_START_URL='{url}' não é uma URL válida.",
            file=sys.stderr,
        )
        sys.exit(1)
    return url


def _validate_persist_home(path: str) -> str:
    # Expande ~ e verifica que não contém caracteres perigosos
    expanded = os.path.expanduser(path)
    if not os.path.isabs(expanded):
        print(f"[ERRO] VNC_PERSIST_HOME='{path}' deve ser um caminho absoluto.", file=sys.stderr)
        sys.exit(1)
    return expanded


# ─── Diretório de persistência ────────────────────────────────────────────────

PERSIST_HOME = _validate_persist_home(
    os.environ.get("VNC_PERSIST_HOME", "~/vnc_persist")
)

# ─── Display virtual ─────────────────────────────────────────────────────────

DISPLAY_NUM = _get_int("VNC_DISPLAY_NUM", 99)
DISPLAY     = f":{DISPLAY_NUM}"

# ─── Resolução ───────────────────────────────────────────────────────────────

SCREEN_RES = _validate_resolution(
    os.environ.get("VNC_SCREEN_RES", "1366x768x24")
)

# ─── Portas ──────────────────────────────────────────────────────────────────

VNC_PORT   = _get_port("VNC_PORT",   5900)
NOVNC_PORT = _get_port("NOVNC_PORT", 6080)

# ─── Senha VNC ───────────────────────────────────────────────────────────────

VNC_PASSWD = _validate_password(
    os.environ.get("VNC_PASSWD", "vncpass")
)

if VNC_PASSWD == "vncpass":
    print(
        "[AVISO] Usando senha VNC padrão insegura.\n"
        "        Defina VNC_PASSWD no arquivo .env antes de usar em produção.",
        file=sys.stderr,
    )

# ─── URL inicial do Chrome ────────────────────────────────────────────────────

CHROME_START_URL = _validate_url(
    os.environ.get("CHROME_START_URL", "https://google.com")
)

# ─── Caminhos fixos ──────────────────────────────────────────────────────────

CLOUDFLARED_PATH = "/usr/local/bin/cloudflared"
NOVNC_DIR        = "/opt/novnc"
CLOUDFLARED_LOG  = "/tmp/cloudflared.log"
