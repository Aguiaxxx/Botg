#!/usr/bin/env python3
"""
main.py — Ponto de entrada principal do VNC Server para VPS Linux
Uso: sudo python3 main.py [--stop] [--no-tunnel] [--no-chrome] [--no-install]
"""

import argparse
import os
import sys


# ─── Verificação de root ──────────────────────────────────────────────────────

def check_root() -> None:
    if os.geteuid() != 0:
        print(
            "\n❌ Este script precisa ser executado como root.\n"
            "   sudo python3 main.py\n",
            file=sys.stderr,
        )
        sys.exit(1)


# ─── Carrega .env antes de qualquer import de config ─────────────────────────

def load_dotenv() -> None:
    """
    Lê o arquivo .env (se existir) e exporta as variáveis para os.environ.
    Variáveis já definidas no ambiente do shell têm prioridade.
    Não usa bibliotecas externas — implementação nativa.
    """
    env_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if not os.path.exists(env_file):
        return

    with open(env_file, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key   = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value


# ─── Imports tardios (após .env) ─────────────────────────────────────────────

check_root()    # antes de qualquer import — falha rápida
load_dotenv()   # popula os.environ antes de config.py ser importado

# config.py valida e aborta em valores inválidos — importado aqui intencionalmente
from config import PERSIST_HOME, DISPLAY, VNC_PASSWD, NOVNC_PORT  # noqa: E402
import installer  # noqa: E402
import services   # noqa: E402
import tunnel     # noqa: E402


# ─── Banner ───────────────────────────────────────────────────────────────────

def print_banner() -> None:
    print("═" * 60)
    print("  VNC XFCE — SERVIDOR REMOTO PARA VPS LINUX")
    print("  XFCE + noVNC + Chrome + Cloudflare Tunnel")
    print("═" * 60)
    print(f"\n  HOME persistente : {PERSIST_HOME}")
    print(f"  Display          : {DISPLAY}")
    print(f"  Senha VNC        : {'*' * len(VNC_PASSWD)}")
    print()


# ─── CLI ─────────────────────────────────────────────────────────────────────

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="VNC XFCE Server para VPS Linux"
    )
    parser.add_argument(
        "--stop",
        action="store_true",
        help="Para todos os serviços e encerra",
    )
    parser.add_argument(
        "--no-tunnel",
        action="store_true",
        help="Não cria túnel Cloudflare (acesso apenas local ou pela porta aberta)",
    )
    parser.add_argument(
        "--no-chrome",
        action="store_true",
        help="Não abre o Chrome automaticamente",
    )
    parser.add_argument(
        "--no-install",
        action="store_true",
        help="Pula a instalação de dependências (use após a 1ª execução)",
    )
    return parser.parse_args()


# ─── Main ────────────────────────────────────────────────────────────────────

def main() -> None:
    args = parse_args()
    print_banner()

    # Cria diretório de persistência
    os.makedirs(PERSIST_HOME, exist_ok=True)
    os.environ["HOME"] = PERSIST_HOME

    # --stop: encerra serviços e sai
    if args.stop:
        print("\n🛑 Parando todos os serviços...")
        services.stop_all()
        tunnel.kill_cloudflared()
        print("✅ Tudo parado.\n")
        return

    # Instalação de dependências
    if not args.no_install:
        installer.ensure_all()
    else:
        print("⏩ Instalação pulada (--no-install)")

    # Inicia serviços — passa flag do Chrome diretamente (sem kill-after)
    services.start_all(open_chrome=not args.no_chrome)

    # Túnel Cloudflare
    if args.no_tunnel:
        print("\n⏩ Túnel Cloudflare não criado (--no-tunnel)")
        tunnel.print_result(None, PERSIST_HOME)
    else:
        public_url = tunnel.start_tunnel()
        tunnel.print_result(public_url, PERSIST_HOME)


if __name__ == "__main__":
    main()
