"""
installer.py — Instalação de dependências do sistema
Falha imediata (sys.exit) em erros críticos de instalação.
"""

import os
import shutil
import subprocess
import sys

from config import CLOUDFLARED_PATH, NOVNC_DIR


# ─── Helpers ──────────────────────────────────────────────────────────────────

def run(
    args: list[str],
    desc: str = "",
    critical: bool = False,
    env: dict | None = None,
) -> subprocess.CompletedProcess:
    """
    Executa um comando como lista de argumentos (sem shell=True).
    Se critical=True e o comando falhar, encerra o processo.
    """
    if desc:
        print(f"⏳ {desc}...")

    r = subprocess.run(
        args,
        text=True,
        capture_output=True,
        env=env,
    )

    if r.returncode != 0:
        err = (r.stderr or r.stdout or "").strip()
        if critical:
            print(f"\n❌ Falha crítica em: {' '.join(args)}", file=sys.stderr)
            if err:
                print(f"   {err[:500]}", file=sys.stderr)
            sys.exit(1)
        elif err:
            print(f"  ⚠  {err[:300]}")

    return r


def run_shell(
    cmd: str,
    desc: str = "",
    critical: bool = False,
    env: dict | None = None,
) -> subprocess.CompletedProcess:
    """
    Executa um comando de shell quando o uso de shell=True é necessário
    (pipelines, redirecionamentos). Não interpola variáveis de usuário.
    """
    if desc:
        print(f"⏳ {desc}...")

    r = subprocess.run(cmd, shell=True, text=True, capture_output=True, env=env)

    if r.returncode != 0:
        err = (r.stderr or r.stdout or "").strip()
        if critical:
            print(f"\n❌ Falha crítica: {cmd}", file=sys.stderr)
            if err:
                print(f"   {err[:500]}", file=sys.stderr)
            sys.exit(1)
        elif err:
            print(f"  ⚠  {err[:300]}")

    return r


def binary_exists(name: str) -> bool:
    return shutil.which(name) is not None


# ─── Funções de instalação ────────────────────────────────────────────────────

def install_system_packages() -> None:
    print("\n" + "═" * 60)
    print("  INSTALANDO DEPENDÊNCIAS DO SISTEMA")
    print("═" * 60)

    run(["apt-get", "update", "-qq"], "Atualizando lista de pacotes", critical=True)

    packages = [
        "xfce4", "xfce4-goodies", "xfce4-terminal",
        "xvfb", "x11vnc", "dbus-x11",
        "wget", "curl", "git",
        "net-tools", "procps",
        "python3", "python3-pip",
    ]

    env = {**__import__("os").environ, "DEBIAN_FRONTEND": "noninteractive"}
    run(
        ["apt-get", "install", "-y", "-qq"] + packages,
        "Instalando pacotes do sistema",
        critical=True,
        env=env,
    )
    print("✅ Pacotes do sistema instalados")


def install_chrome() -> None:
    if binary_exists("google-chrome"):
        print("✅ Google Chrome já instalado")
        return

    print("⏳ Baixando Google Chrome...")
    run(
        [
            "wget", "-q",
            "https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb",
            "-O", "/tmp/chrome.deb",
        ],
        critical=True,
    )

    env = {**__import__("os").environ, "DEBIAN_FRONTEND": "noninteractive"}
    run(
        ["apt", "install", "-y", "-qq", "/tmp/chrome.deb"],
        "Instalando Chrome",
        critical=True,
        env=env,
    )
    run(["rm", "-f", "/tmp/chrome.deb"])

    if binary_exists("google-chrome"):
        print("✅ Google Chrome instalado")
    else:
        print("❌ Falha ao instalar Google Chrome — verifique sua conexão.", file=sys.stderr)
        sys.exit(1)


def install_novnc() -> None:
    if os.path.exists(NOVNC_DIR):
        print("✅ noVNC já instalado")
    else:
        run(
            ["git", "clone", "--depth", "1",
             "https://github.com/novnc/noVNC.git", NOVNC_DIR],
            "Clonando noVNC",
            critical=True,
        )
        run(
            ["git", "clone", "--depth", "1",
             "https://github.com/novnc/websockify.git",
             f"{NOVNC_DIR}/utils/websockify"],
            "Clonando websockify",
            critical=True,
        )

    # Symlink seguro (sem shell=True)
    index = os.path.join(NOVNC_DIR, "index.html")
    vnc_html = os.path.join(NOVNC_DIR, "vnc.html")
    if os.path.lexists(index):
        os.remove(index)
    os.symlink(vnc_html, index)
    print("✅ noVNC pronto")


def install_cloudflared() -> None:
    if os.path.exists(CLOUDFLARED_PATH):
        print("✅ Cloudflared já instalado")
        return

    print("⏳ Baixando Cloudflared...")
    tmp = "/tmp/cloudflared"
    run(
        [
            "wget", "-q",
            "https://github.com/cloudflare/cloudflared/releases/latest/download/"
            "cloudflared-linux-amd64",
            "-O", tmp,
        ],
        critical=True,
    )
    os.chmod(tmp, 0o755)
    shutil.move(tmp, CLOUDFLARED_PATH)
    print("✅ Cloudflared instalado")


def ensure_all() -> None:
    """Garante que todas as dependências estão instaladas. Aborta em falha crítica."""
    install_system_packages()
    install_chrome()
    install_novnc()
    install_cloudflared()
